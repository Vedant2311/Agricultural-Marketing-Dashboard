# DBMS Project

By Kamal, Mayur, and Vedant. Making use of the demo website developed by us for our BTP-1.
