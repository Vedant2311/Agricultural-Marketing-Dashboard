export TEMPLATES_AUTO_RELOAD=True
export FLASK_APP=FRONT_END/app
export FLASK_ENV=development
flask run -h localhost -p 5016
